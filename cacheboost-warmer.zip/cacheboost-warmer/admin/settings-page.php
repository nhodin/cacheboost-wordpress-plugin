<?php
if (!defined('ABSPATH')) exit;

add_action('admin_init', function () {
    register_setting('cbwarmer_settings', 'cbwarmer_options', [
        'sanitize_callback' => 'cbwarmer_sanitize_options',
    ]);
});

add_action('wp_ajax_cbwarmer_test_connection', 'cbwarmer_ajax_test_connection');
add_action('wp_ajax_cbwarmer_fetch_boosts',   'cbwarmer_ajax_fetch_boosts');

add_action('admin_enqueue_scripts', 'cbwarmer_enqueue_settings_assets');

add_action('admin_post_cbwarmer_connect', 'cbwarmer_start_connect');
// After register_setting() (priority 10) so saving the new key goes through cbwarmer_sanitize_options().
add_action('admin_init', 'cbwarmer_handle_connect_callback', 20);

function cbwarmer_connect_url(): string {
    return wp_nonce_url(admin_url('admin-post.php?action=cbwarmer_connect'), 'cbwarmer_connect');
}

function cbwarmer_start_connect(): void {
    if (!current_user_can('manage_options')) wp_die();
    check_admin_referer('cbwarmer_connect');
    // External on purpose: the CacheBoost sign-up / consent page.
    wp_redirect(\CacheBoostWarmer\Connect::authorize_url());
    exit;
}

/**
 * Return from app.cache-boost.com/connect/wordpress (?state=…&code=… or &error=…).
 * The state must match a transient created by this admin, which also protects this request against CSRF.
 */
function cbwarmer_handle_connect_callback(): void {
    if (($_GET['page'] ?? '') !== 'cbwarmer' || !isset($_GET['state']) || !current_user_can('manage_options')) return;

    $result = \CacheBoostWarmer\Connect::handle_callback(
        sanitize_text_field(wp_unslash($_GET['state'])),
        sanitize_text_field(wp_unslash($_GET['code'] ?? '')),
        sanitize_text_field(wp_unslash($_GET['error'] ?? ''))
    );

    if ($result['success']) {
        $opts      = get_option('cbwarmer_options', []);
        $ping      = \CacheBoostWarmer\ApiClient::ping($result['api_key'], 'https://api.cache-boost.com');
        $available = $ping['regions'] ?? [];
        // Same default region as the settings form: the admin's choice, else US, else any available region.
        $preferred = array_values(array_intersect($opts['regions'] ?? [], $available))
            ?: (in_array('us', $available, true) ? ['us'] : $available);
        $boost_id  = \CacheBoostWarmer\Connect::ensure_full_warming_boost($result['api_key'], $result['site_id'], $preferred);

        // Same input as the settings form: cbwarmer_sanitize_options() resolves the site and validates the domain.
        update_option('cbwarmer_options', [
            'enabled'          => 1,
            'api_key'          => $result['api_key'],
            'smart_enabled'    => $opts['smart_enabled'] ?? true,
            'full_enabled'     => $opts['full_enabled'] ?? true,
            'boost_id'         => $boost_id ?: (int) ($opts['boost_id'] ?? 0),
            'stock_warming'    => $opts['stock_warming'] ?? false,
            'flyingpress_warming' => $opts['flyingpress_warming'] ?? true,
            'dashboard_widget' => $opts['dashboard_widget'] ?? true,
            'regions'          => $opts['regions'] ?? [],
        ]);
    }

    // Drop the one-time code from the URL and the browser history.
    wp_safe_redirect(admin_url('admin.php?page=cbwarmer&cbwarmer_connect=' . ($result['success'] ? 'ok' : $result['reason'])));
    exit;
}

function cbwarmer_render_connect_notice(): void {
    $status = sanitize_key($_GET['cbwarmer_connect'] ?? '');
    $notices = [
        'ok'              => ['success', __('Connected to CacheBoost. Your pages will be warmed after each cache purge.', 'cacheboost-warmer')],
        'denied'          => ['warning', __('Connection cancelled.', 'cacheboost-warmer')],
        'invalid_state'   => ['error', __('The connection link expired or was opened in another session. Please try again.', 'cacheboost-warmer')],
        'exchange_failed' => ['error', __('Could not finish connecting to CacheBoost. Please try again, or paste an API key below.', 'cacheboost-warmer')],
    ];
    if (!isset($notices[$status])) return;

    [$type, $message] = $notices[$status];
    printf('<div class="notice notice-%s is-dismissible"><p>%s</p></div>', esc_attr($type), esc_html($message));
}

/**
 * Labels for the region codes returned by GET /v1/me (ISO 3166-1 alpha-2).
 * A code missing here is shown upper-cased, so a new CacheBoost region still appears.
 * 'uk' is the legacy code of 'gb', kept for region lists cached before 1.0.3.
 */
function cbwarmer_region_labels(): array {
    return [
        'fr' => 'France',
        'de' => 'Germany',
        'gb' => 'United Kingdom',
        'uk' => 'United Kingdom',
        'us' => 'United States',
        'es' => 'Spain',
        'it' => 'Italy',
        'ch' => 'Switzerland',
        'sg' => 'Singapore',
        'in' => 'India',
        'au' => 'Australia',
        'br' => 'Brazil',
        'ca' => 'Canada',
    ];
}

function cbwarmer_enqueue_settings_assets(string $hook): void {
    if ($hook !== 'toplevel_page_cbwarmer') return;

    $options           = get_option('cbwarmer_options', ['enabled' => true]);
    $available_regions = $options['available_regions'] ?? [];
    $selected_regions  = $options['regions'] ?? [];
    if (empty($selected_regions) && in_array('us', $available_regions, true)) {
        $selected_regions = ['us'];
    }

    wp_enqueue_script(
        'cbwarmer-settings',
        plugins_url('js/settings.js', __FILE__),
        [],
        CBWARMER_VERSION,
        true
    );
    wp_localize_script('cbwarmer-settings', 'CacheBoostWarmerSettings', [
        'ajaxUrl'         => admin_url('admin-ajax.php'),
        'nonce'           => wp_create_nonce('cbwarmer_test_nonce'),
        'clearLogsNonce'  => wp_create_nonce('cbwarmer_clear_logs_nonce'),
        'savedBoostId'    => (string) ($options['boost_id'] ?? ''),
        'regionLabels'    => cbwarmer_region_labels(),
        'selectedRegions' => $selected_regions,
        'i18n'            => [
            'loading'       => __('Loading…', 'cacheboost-warmer'),
            'noApiKey'      => __('Save a valid API key first.', 'cacheboost-warmer'),
            'noSiteId'      => __('Test the connection first to identify your site.', 'cacheboost-warmer'),
            'loadFailed'    => __('Failed to load boosts.', 'cacheboost-warmer'),
            'noBoosts'      => __('No boosts found for this site.', 'cacheboost-warmer'),
            'stale'         => __('Previously selected boost no longer exists.', 'cacheboost-warmer'),
            'testing'       => __('Testing…', 'cacheboost-warmer'),
            'requestFailed' => __('Request failed.', 'cacheboost-warmer'),
            'noActivity'    => __('No activity logged yet.', 'cacheboost-warmer'),
            'regionsHelp'   => __('Select which regions will warm your cache. Leave all unchecked to use every available region.', 'cacheboost-warmer'),
        ],
    ]);
}

function cbwarmer_ajax_fetch_boosts(): void {
    check_ajax_referer('cbwarmer_test_nonce', 'nonce');
    if (!current_user_can('manage_options')) wp_die();

    $options = get_option('cbwarmer_options', []);
    $api_key = $options['api_key'] ?? '';
    $site_id = $options['site_id'] ?? null;

    if (!\CacheBoostWarmer\ApiClient::is_valid_api_key($api_key)) {
        wp_send_json_error(['code' => 'no_api_key']);
    }

    if (!$site_id) {
        wp_send_json_error(['code' => 'no_site_id']);
    }

    $result = \CacheBoostWarmer\ApiClient::fetch_boosts_for_site($api_key, (int) $site_id);

    if (!$result['success']) {
        wp_send_json_error(['code' => 'api_error', 'message' => $result['message'] ?? '']);
    }

    wp_send_json_success(['boosts' => $result['boosts']]);
}

function cbwarmer_ajax_test_connection(): void {
    check_ajax_referer('cbwarmer_test_nonce', 'nonce');
    if (!current_user_can('manage_options')) wp_die();

    $options  = get_option('cbwarmer_options', []);
    $api_key  = $options['api_key'] ?? '';
    $endpoint = 'https://api.cache-boost.com';

    if (!\CacheBoostWarmer\ApiClient::is_valid_api_key($api_key)) {
        wp_send_json_error(['message' => __('Invalid API key format.', 'cacheboost-warmer')]);
    }

    $result = \CacheBoostWarmer\ApiClient::ping($api_key, $endpoint);

    if ($result['success']) {
        $scopes   = $result['scopes'] ?? [];
        $required = ['sites:read', 'boosts:read', 'boosts:write', 'runs:read'];
        $missing  = array_diff($required, $scopes);

        if (!empty($missing)) {
            wp_send_json_error(['message' => sprintf(
                /* translators: %s: comma-separated list of missing API scopes */
                __('Connected, but missing required scopes: %s. Please regenerate your API key with the correct permissions.', 'cacheboost-warmer'),
                implode(', ', $missing)
            )]);
        }

        $home_domain = (string) preg_replace('#^https?://#', '', rtrim(home_url(), '/'));
        $matched     = null;
        foreach ($result['sites'] ?? [] as $site) {
            if (rtrim((string) ($site['domain'] ?? ''), '/') === $home_domain) {
                $matched = $site;
                break;
            }
        }

        if ($matched === null) {
            wp_send_json_error(['message' => sprintf(
                /* translators: %s: current site domain */
                __('Connected, but %s is not registered in your CacheBoost account. Please add your domain at app.cache-boost.com.', 'cacheboost-warmer'),
                $home_domain
            )]);
        }

        $validation = \CacheBoostWarmer\SiteValidation::ensure($api_key, $matched);
        if (!$validation['success']) {
            wp_send_json_error(['message' => sprintf(
                /* translators: 1: current site domain, 2: error detail */
                __('Connected, but %1$s could not be validated automatically (%2$s). Please complete domain validation in your CacheBoost account.', 'cacheboost-warmer'),
                $home_domain,
                $validation['message'] ?? ''
            )]);
        }

        // Persist site_id and available regions so send() and the form work without re-testing
        $opts = get_option('cbwarmer_options', []);
        $opts['available_regions'] = $result['regions'] ?? [];
        $opts['site_id'] = $matched['id'] ?? null;
        update_option('cbwarmer_options', $opts);

        wp_send_json_success([
            'message' => __('Connection successful. Scopes and site access verified.', 'cacheboost-warmer'),
            'regions' => $result['regions'] ?? [],
        ]);
    } else {
        wp_send_json_error(['message' => sprintf(
            /* translators: %s: error detail */
            __('Connection failed: %s', 'cacheboost-warmer'),
            $result['message'] ?? ''
        )]);
    }
}

add_action('wp_ajax_cbwarmer_clear_logs', 'cbwarmer_ajax_clear_logs');

function cbwarmer_ajax_clear_logs(): void {
    check_ajax_referer('cbwarmer_clear_logs_nonce', 'nonce');
    if (!current_user_can('manage_options')) wp_die();
    \CacheBoostWarmer\Logger::clear();
    wp_send_json_success();
}

function cbwarmer_sanitize_options(array $input): array {
    $old    = get_option('cbwarmer_options', []);
    $output = [];

    $output['enabled'] = !empty($input['enabled']);

    $key = sanitize_text_field($input['api_key'] ?? '');
    if (preg_match('/^cb_live_[a-zA-Z0-9]+$/', $key)) {
        $output['api_key'] = $key;
    } else {
        $output['api_key'] = '';
        add_settings_error(
            'cbwarmer_options',
            'invalid_api_key',
            __('Invalid API key. Expected format: cb_live_...', 'cacheboost-warmer'),
            'error'
        );
    }

    $output['smart_enabled'] = !empty($input['smart_enabled']);
    $output['full_enabled']  = !empty($input['full_enabled']);

    $output['boost_id'] = max(0, (int) ($input['boost_id'] ?? 0));

    $output['stock_warming']    = !empty($input['stock_warming']);
    $output['dashboard_widget'] = !empty($input['dashboard_widget']);
    // The checkbox is only rendered while FlyingPress is active: keep the stored value (on by default) otherwise.
    $output['flyingpress_warming'] = class_exists('FlyingPress\Purge')
        ? !empty($input['flyingpress_warming'])
        : (bool) ($old['flyingpress_warming'] ?? true);

    $output['api_endpoint'] = 'https://api.cache-boost.com';

    // Log changed fields
    $changes = [];
    if (($old['enabled'] ?? false) !== $output['enabled']) {
        $changes[] = 'enabled: ' . ($output['enabled'] ? 'yes' : 'no');
    }
    if (($old['api_key'] ?? '') !== ($output['api_key'] ?? '')) {
        $key_preview = $output['api_key'] ? substr($output['api_key'], 0, 10) . '...' : '(cleared)';
        $changes[] = 'api_key: ' . $key_preview;
    }
    if (($old['smart_enabled'] ?? true) !== $output['smart_enabled']) {
        $changes[] = 'smart_enabled: ' . ($output['smart_enabled'] ? 'yes' : 'no');
    }
    if (($old['full_enabled'] ?? true) !== $output['full_enabled']) {
        $changes[] = 'full_enabled: ' . ($output['full_enabled'] ? 'yes' : 'no');
    }
    if (($old['stock_warming'] ?? false) !== $output['stock_warming']) {
        $changes[] = 'stock_warming: ' . ($output['stock_warming'] ? 'yes' : 'no');
    }
    if (($old['flyingpress_warming'] ?? true) !== $output['flyingpress_warming']) {
        $changes[] = 'flyingpress_warming: ' . ($output['flyingpress_warming'] ? 'yes' : 'no');
    }
    if (($old['boost_id'] ?? 0) !== $output['boost_id']) {
        $changes[] = 'boost_id: ' . ($output['boost_id'] ?: '(none)');
    }

    $current    = get_option('cbwarmer_options', []);
    $key_changed = ($old['api_key'] ?? '') !== ($output['api_key'] ?? '');

    if ($key_changed) {
        // Validation status and account state belonged to the previous key/site.
        delete_option(\CacheBoostWarmer\SiteValidation::STATUS_OPTION);
        \CacheBoostWarmer\AccountStatus::clear();
    }

    if ($key_changed && !empty($output['api_key'])) {
        // Resolve site_id and regions immediately so send() works without clicking "Test Connection"
        $ping = \CacheBoostWarmer\ApiClient::ping($output['api_key'], $output['api_endpoint']);
        if ($ping['success']) {
            $home_domain = (string) preg_replace('#^https?://#', '', rtrim(home_url(), '/'));
            $matched_site = null;
            foreach ($ping['sites'] ?? [] as $s) {
                if (rtrim((string) ($s['domain'] ?? ''), '/') === $home_domain) {
                    $matched_site = $s;
                    break;
                }
            }
            $output['available_regions'] = $ping['regions'] ?? [];
            $output['site_id']           = $matched_site['id'] ?? null;

            // Without validation every warm request is rejected (409) silently, so validate now.
            if ($matched_site !== null) {
                $validation = \CacheBoostWarmer\SiteValidation::ensure($output['api_key'], $matched_site);
                if ($validation['attempted'] && $validation['success']) {
                    add_settings_error(
                        'cbwarmer_options',
                        'site_validated',
                        __('Your domain has been validated in CacheBoost.', 'cacheboost-warmer'),
                        'success'
                    );
                }
            }
        }
    } else {
        // Preserve values written by the AJAX test (or a previous save)
        if (array_key_exists('available_regions', $current)) {
            $output['available_regions'] = $current['available_regions'];
        }
        if (array_key_exists('site_id', $current)) {
            $output['site_id'] = $current['site_id'];
        }
    }

    // Sanitize selected regions (format-validate slugs; intersect only when available list is known)
    $submitted = array_values(array_filter((array) ($input['regions'] ?? []), fn($v) => is_string($v) && preg_match('/^[a-z]{2,5}$/', $v)));
    $available = $output['available_regions'] ?? [];
    $output['regions'] = !empty($available)
        ? array_values(array_intersect($submitted, $available))
        : $submitted;

    if (($old['regions'] ?? []) !== $output['regions']) {
        $changes[] = 'regions: ' . (empty($output['regions']) ? '(all)' : implode(', ', $output['regions']));
    }

    if (!empty($changes)) {
        \CacheBoostWarmer\Logger::log('settings', 'Settings saved — ' . implode(', ', $changes));
    }

    return $output;
}

function cbwarmer_render_settings_page(): void {
    if (!current_user_can('manage_options')) return;

    $options = get_option('cbwarmer_options', ['enabled' => true]);

    $smart_enabled     = $options['smart_enabled'] ?? true;
    $full_enabled      = $options['full_enabled']  ?? true;
    $available_regions = $options['available_regions'] ?? [];
    $selected_regions  = $options['regions'] ?? [];

    if (empty($selected_regions) && in_array('us', $available_regions, true)) {
        $selected_regions = ['us'];
    }

    $region_labels = cbwarmer_region_labels();
    ?>
    <div class="wrap">
        <?php cbwarmer_render_admin_header(__('CacheBoost Warmer', 'cacheboost-warmer')); ?>
        <?php settings_errors('cbwarmer_options'); ?>
        <?php cbwarmer_render_connect_notice(); ?>

        <?php if (!empty($options['api_key']) && \CacheBoostWarmer\SiteValidation::is_pending()): ?>
            <div class="notice notice-warning inline">
                <p>
                    <strong><?php esc_html_e('Your domain is not validated in CacheBoost.', 'cacheboost-warmer'); ?></strong>
                    <?php esc_html_e('Cache warming requests will be rejected until it is. Automatic validation failed: see the activity log for details.', 'cacheboost-warmer'); ?>
                </p>
                <p>
                    <a href="https://app.cache-boost.com/sites" target="_blank" rel="noopener" class="button">
                        <?php esc_html_e('See validation methods', 'cacheboost-warmer'); ?>
                    </a>
                </p>
            </div>
        <?php endif; ?>

        <form method="post" action="options.php">
            <?php settings_fields('cbwarmer_settings'); ?>

            <table class="form-table" role="presentation">

                <tr>
                    <th scope="row"><?php esc_html_e('CacheBoost account', 'cacheboost-warmer'); ?></th>
                    <td>
                        <?php if (empty($options['api_key'])): ?>
                            <a href="<?php echo esc_url(cbwarmer_connect_url()); ?>" class="button button-primary">
                                <?php esc_html_e('Connect to CacheBoost', 'cacheboost-warmer'); ?>
                            </a>
                            <p class="description">
                                <?php esc_html_e('Sign in or create a free account (500 URLs per month, no credit card). Your site, its sitemap and the full-site warming are set up automatically.', 'cacheboost-warmer'); ?>
                            </p>
                        <?php else: ?>
                            <span class="dashicons dashicons-yes-alt" style="color:#46b450;vertical-align:middle"></span>
                            <?php esc_html_e('Connected', 'cacheboost-warmer'); ?>
                            <a href="<?php echo esc_url(cbwarmer_connect_url()); ?>" class="button" style="margin-left:8px">
                                <?php esc_html_e('Reconnect', 'cacheboost-warmer'); ?>
                            </a>
                        <?php endif; ?>
                    </td>
                </tr>

                <tr>
                    <th scope="row"><?php esc_html_e('Enable', 'cacheboost-warmer'); ?></th>
                    <td>
                        <label>
                            <input type="checkbox" name="cbwarmer_options[enabled]" value="1"
                                <?php checked($options['enabled'] ?? true); ?> />
                            <?php esc_html_e('Activate cache warming after purge events', 'cacheboost-warmer'); ?>
                        </label>
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="cb_api_key"><?php esc_html_e('API Key', 'cacheboost-warmer'); ?></label>
                    </th>
                    <td>
                        <input type="text" id="cb_api_key" name="cbwarmer_options[api_key]"
                               value="<?php echo esc_attr($options['api_key'] ?? ''); ?>"
                               class="regular-text" placeholder="cb_live_..." autocomplete="off" />
                        <p class="description">
                            <?php
                            echo wp_kses(
                                sprintf(
                                    /* translators: %s: link to CacheBoost profile page */
                                    __('Filled in automatically when you connect. You can also paste a key generated in your <a href="%s" target="_blank" rel="noopener">CacheBoost profile</a> (scopes: <code>sites:read</code>, <code>boosts:read</code>, <code>boosts:write</code>, <code>runs:read</code>).', 'cacheboost-warmer'),
                                    'https://app.cache-boost.com/profile'
                                ),
                                ['code' => [], 'a' => ['href' => [], 'target' => [], 'rel' => []]]
                            );
                            ?>
                        </p>
                    </td>
                </tr>

                <tr>
                    <th scope="row"><?php esc_html_e('Warming triggers', 'cacheboost-warmer'); ?></th>
                    <td>
                        <fieldset>
                            <label>
                                <input type="checkbox" name="cbwarmer_options[smart_enabled]" value="1"
                                    <?php checked($smart_enabled); ?> />
                                <strong><?php esc_html_e('Smart', 'cacheboost-warmer'); ?></strong>
                            </label>
                            <p class="description"><?php esc_html_e('Warms only the affected URLs when a post or term is saved, or when a cache plugin purges a specific page.', 'cacheboost-warmer'); ?></p>
                            <br>
                            <label>
                                <input type="checkbox" name="cbwarmer_options[full_enabled]" value="1"
                                    <?php checked($full_enabled); ?> />
                                <strong><?php esc_html_e('Full', 'cacheboost-warmer'); ?></strong>
                            </label>
                            <p class="description"><?php esc_html_e('Warms the entire site when a global cache flush occurs (theme switch, menu update, plugin upgrade, or full cache purge).', 'cacheboost-warmer'); ?></p>
                        </fieldset>
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="cb_boost_id"><?php esc_html_e('Full Warming Boost', 'cacheboost-warmer'); ?></label>
                    </th>
                    <td>
                        <select id="cb_boost_id" name="cbwarmer_options[boost_id]" disabled>
                            <option value=""><?php esc_html_e('Loading…', 'cacheboost-warmer'); ?></option>
                        </select>
                        <p class="description">
                            <?php esc_html_e('The scheduled Boost to run on full cache flushes (theme switch, plugin upgrade, full purge). Required for Full warming to work.', 'cacheboost-warmer'); ?>
                        </p>
                        <p id="cb-no-boost-msg" style="display:none">
                            <?php
                            printf(
                                /* translators: %s: link to create a boost */
                                esc_html__('No boosts found for this site. %s', 'cacheboost-warmer'),
                                '<a href="https://app.cache-boost.com/boosts/create" target="_blank" rel="noopener">'
                                    . esc_html__('Create a Boost', 'cacheboost-warmer')
                                . '</a>'
                            );
                            ?>
                        </p>
                    </td>
                </tr>

                <?php if (class_exists('WooCommerce')): ?>
                <tr>
                    <th scope="row"><?php esc_html_e('Stock Warming', 'cacheboost-warmer'); ?></th>
                    <td>
                        <label>
                            <input type="checkbox" name="cbwarmer_options[stock_warming]" value="1"
                                <?php checked(!empty($options['stock_warming'])); ?> />
                            <?php esc_html_e('Warm product pages when stock changes (e.g. after an order)', 'cacheboost-warmer'); ?>
                        </label>
                    </td>
                </tr>
                <?php endif; ?>

                <?php if (class_exists('FlyingPress\Purge')): ?>
                <tr>
                    <th scope="row"><?php esc_html_e('FlyingPress', 'cacheboost-warmer'); ?></th>
                    <td>
                        <label>
                            <input type="checkbox" name="cbwarmer_options[flyingpress_warming]" value="1"
                                <?php checked($options['flyingpress_warming'] ?? true); ?> />
                            <?php esc_html_e('Warm the cache after each FlyingPress purge', 'cacheboost-warmer'); ?>
                        </label>
                        <p class="description"><?php esc_html_e('A full purge runs the Full Warming Boost, a page purge warms that page only. Purges less than a minute apart trigger a single warm.', 'cacheboost-warmer'); ?></p>
                    </td>
                </tr>
                <?php endif; ?>

                <tr>
                    <th scope="row"><?php esc_html_e('Dashboard Widget', 'cacheboost-warmer'); ?></th>
                    <td>
                        <label>
                            <input type="checkbox" name="cbwarmer_options[dashboard_widget]" value="1"
                                <?php checked($options['dashboard_widget'] ?? true); ?> />
                            <?php esc_html_e('Show last warming run stats on the WordPress dashboard', 'cacheboost-warmer'); ?>
                        </label>
                    </td>
                </tr>

                <tr id="cb-regions-row">
                    <th scope="row"><?php esc_html_e('Warm Regions', 'cacheboost-warmer'); ?></th>
                    <td>
                        <?php if (empty($available_regions)): ?>
                            <p class="description">
                                <?php esc_html_e('Test the connection above to see available regions.', 'cacheboost-warmer'); ?>
                            </p>
                        <?php else: ?>
                            <fieldset>
                                <?php foreach ($available_regions as $slug):
                                    $label = $region_labels[$slug] ?? strtoupper($slug);
                                ?>
                                <label style="margin-right:16px">
                                    <input type="checkbox"
                                           name="cbwarmer_options[regions][]"
                                           value="<?php echo esc_attr($slug); ?>"
                                           <?php checked(in_array($slug, $selected_regions, true)); ?> />
                                    <?php echo esc_html($label); ?>
                                </label>
                                <?php endforeach; ?>
                            </fieldset>
                            <p class="description">
                                <?php esc_html_e('Select which regions will warm your cache. Leave all unchecked to use every available region.', 'cacheboost-warmer'); ?>
                            </p>
                        <?php endif; ?>
                    </td>
                </tr>

                <tr>
                    <th scope="row"><?php esc_html_e('Test Connection', 'cacheboost-warmer'); ?></th>
                    <td>
                        <button type="button" id="cb-test-connection" class="button">
                            <?php esc_html_e('Test Connection', 'cacheboost-warmer'); ?>
                        </button>
                        <span id="cb-test-result" style="margin-left:10px;vertical-align:middle;"></span>
                    </td>
                </tr>

            </table>

            <?php submit_button(); ?>
        </form>
    </div>

    <?php
    $logs = \CacheBoostWarmer\Logger::get_logs();
    $channel_colors = ['buffer' => '#0073aa', 'api' => '#46b450', 'settings' => '#826eb4'];
    ?>
    <hr style="margin-top:24px">
    <details id="cb-logs-accordion">
        <summary style="cursor:pointer;font-weight:600;margin:16px 0 8px;font-size:14px">
            <?php esc_html_e('Activity Log', 'cacheboost-warmer'); ?>
            <?php if (!empty($logs)): ?>
                <span style="font-weight:normal;color:#888;font-size:12px">
                    (<?php echo count($logs); ?>)
                </span>
            <?php endif; ?>
        </summary>

        <?php if (empty($logs)): ?>
            <p class="description"><?php esc_html_e('No activity logged yet.', 'cacheboost-warmer'); ?></p>
        <?php else: ?>
            <button type="button" id="cb-clear-logs" class="button button-small" style="margin-bottom:8px">
                <?php esc_html_e('Clear logs', 'cacheboost-warmer'); ?>
            </button>
            <table class="widefat striped" style="max-width:960px">
                <thead>
                    <tr>
                        <th style="width:150px"><?php esc_html_e('Time', 'cacheboost-warmer'); ?></th>
                        <th style="width:80px"><?php esc_html_e('Channel', 'cacheboost-warmer'); ?></th>
                        <th><?php esc_html_e('Message', 'cacheboost-warmer'); ?></th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($logs as $entry):
                    $ch    = $entry['ch'] ?? '';
                    $color = $channel_colors[$ch] ?? '#888';
                    $lvl   = $entry['lvl'] ?? 'info';
                ?>
                    <tr<?php echo $lvl === 'error' ? ' style="color:#cc0000"' : ''; ?>>
                        <td style="white-space:nowrap"><?php echo esc_html(wp_date('Y-m-d H:i:s', $entry['ts'])); ?></td>
                        <td>
                            <span style="background:<?php echo esc_attr($color); ?>;color:#fff;padding:1px 7px;border-radius:3px;font-size:11px">
                                <?php echo esc_html($ch); ?>
                            </span>
                        </td>
                        <td><?php echo esc_html($entry['msg'] ?? ''); ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </details>

    <?php cbwarmer_render_last_flush(); ?>
    <?php
}
